const fs = require('fs');

const logData = [
    { level: 'info', message: 'Aplikasi telah dimulai.' },
    { level: 'error', message: 'Terjadi Kesalahan.' },
    { level: 'warn', message: 'Peringatan: proses belum selesai.' }
];

// Step 3: Menulis log ke dalam file logging.txt
const writeLogsToFile = () => {
    const logText = logData.map(log => `${log.level}: ${log.message}`).join('\n');

    fs.writeFile('log.txt', logText, (err) => {
        if (err) throw err;
        console.log('Log berhasil ditulis ke dalam log.txt');
    });
};

// Step 4: Menjalankan fungsi untuk menulis log
writeLogsToFile();