console.log('Halo, ini proyek Node.js pertamaku!');
