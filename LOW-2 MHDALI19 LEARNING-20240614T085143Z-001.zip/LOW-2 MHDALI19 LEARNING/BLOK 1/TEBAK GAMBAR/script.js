const BA = document.querySelectorAll(".bagianawal")


function MULAI() {

}