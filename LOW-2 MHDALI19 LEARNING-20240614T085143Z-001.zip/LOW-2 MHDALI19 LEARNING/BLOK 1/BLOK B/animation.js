spriteAnimations = [
    "idle" = {
        width: 525,
        height: 523,
        loc: [
            { x: 0, y: 0 },
            { x: 575, y: 0 },
            { x: 1150, y: 0 },
        ]
    },
    "jump" = {
        width: 120,
        height: 120,
        loc: []
    },
    "run" = {
        width: 1200,
        height: 1250,
        loc: []
    },

];