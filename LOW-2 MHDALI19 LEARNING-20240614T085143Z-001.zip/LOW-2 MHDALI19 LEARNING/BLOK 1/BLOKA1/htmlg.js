

// let d = document.getElementById("myCanvas");
// let cbr = d.getContext("2d");
// cbr.moveTo(0, 0);
// cbr.lineTo(100, 200);
// cbr.stroke();

// // Mendapatkan elemen canvas dengan id "myCanvas"
// var c = document.getElementById("myCanvas");

// // Mendapatkan alat gambar (konteks gambar) di dalam elemen canvas
// var ctx = c.getContext("2d");

// // Memulai menggambar sesuatu (dalam hal ini, lingkaran)
// ctx.beginPath();

// // Menggambar lingkaran di posisi (95, 50) dengan radius 40
// // 0 dan 2 * Math.PI menunjukkan bahwa kita ingin menggambar seluruh lingkaran
// ctx.arc(95, 50, 40, 5, 5 * Math.PI);

// // Menerapkan gambar lingkaran yang telah kita buat
// ctx.stroke();

// var c = document.getElementById("myCanvas");
// var ctx = c.getContext("2d");
// ctx.font = "30px Arial";
// ctx.fillText("Hello World", 20, 50);

// var c = document.getElementById("myCanvas");
// var ctx = c.getContext("2d");

// // Create gradient
// var grd = ctx.createLinearGradient(0, 0, 200, 100);
// grd.addColorStop(0, "red");
// grd.addColorStop(1, "white");

// // Fill with gradient
// ctx.fillStyle = grd;
// // ctx.fillRect(10, 10, 150, 80);

// var c = document.getElementById("myCanvas");
// var ctx = c.getContext("2d");
// var img = document.getElementById("scream");
// ctx.drawImage(img, -250, -600);