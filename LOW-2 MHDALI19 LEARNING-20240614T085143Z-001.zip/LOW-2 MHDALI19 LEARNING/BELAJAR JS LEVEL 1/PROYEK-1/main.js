let tombolmulai = document.querySelector('.tombolmulai');



// Event untuk tekan tombol mulai 
tombolmulai.addEventListener('click', () => {
    let nama = prompt("Masukkan Nama Anda");

    let daftarnama = document.createElement('h2');
    daftarnama.textContent = "Nama: " + nama;
    daftarnama.style.color = "white";
    daftarnama.style.textAlign = "center";

    let daftar = document.getElementById('daftar');

    daftar.appendChild(daftarnama);

    if (!isNaN(nama)) {
        alert("Harap masukkan Nama anda dengan benar");

        return;
    }


    let umur = prompt("Masukkan Umur Anda");
    if (umur <= 17) {
        alert("Umur anda tidak mencukupi")
    } else {
        alert("Terima Kasih Telah mengisi data, Silahkan bermain");
    }


    // Membuat elemen h2 untuk umur
    let daftarumur = document.createElement('h2');
    daftarumur.textContent = "Umur: " + umur;
    daftarumur.style.color = "white";
    daftarumur.style.textAlign = "center";

    // Memilih elemen dengan kelas 'daftar' di dalam DOM


    // Menambahkan elemen-elemen ke dalam elemen dengan kelas 'daftar'

    daftar.appendChild(daftarumur);

});

let bilanganPertama;
let bilanganKedua;

let input = document.getElementById('input')


let satu = document.querySelector('.satu');
let dua = document.querySelector('.dua');
let tiga = document.querySelector('.tiga');
let empat = document.querySelector('.empat');
let lima = document.querySelector('.lima');
let enam = document.querySelector('.enam');
let tujuh = document.querySelector('.tujuh');
let delapan = document.querySelector('.delapan');
let sembilan = document.querySelector('.sembilan');
let nol = document.querySelector('.nol')

satu.addEventListener("click", () => {



})
function tambahAngka(angka) {
    input.value += angka;
}



// Event ketika tekan tombol nol 
nol.addEventListener('click', () => {
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("HAHHAHHAHAAHhHAHAHAHAHAHHAHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("KALAH HAHAHAHAHAHHAHAHAHAHHAH")
    alert("MAU SAMPAI KAPAN BROO DITEKANNYA?")
    return;
})

