// Kalkulator Sederhana:

// Minta pengguna memasukkan dua angka.
let input = Number(prompt('masukkan angka 1'));
let input2 = Number(prompt('masukkan angka 2'));


// Minta pengguna memilih operasi matematika (penambahan, pengurangan, perkalian, pembagian).
let operasi = prompt('masukkan operasi (+,:,X,-)');

// Hitung dan tampilkan hasil operasi matematika tersebut.
let hasil;
if (operasi === "+") {
    hasil = input + input2;
} else if (operasi === "-") {
    hasil = input - input2;
} else if (operasi === "X") {
    hasil = input * input2;
} else if (input === 0 && input2 === 0 && operasi === ":") {
    alert("Harap otak nya dipasang terlebih dahulu, sekian terima kasih ")
} else if (operasi === ":") {
    hasil = input / input2;
}
else {
    let bukan;
    bukan = alert('masukkan sesuai aturan')
}

if (hasil !== bukan) {
    alert(`Hasil dari operasi ${input} ${operasi} ${input2} adalah ${hasil}`);
} else {
    alert("tolol")
}