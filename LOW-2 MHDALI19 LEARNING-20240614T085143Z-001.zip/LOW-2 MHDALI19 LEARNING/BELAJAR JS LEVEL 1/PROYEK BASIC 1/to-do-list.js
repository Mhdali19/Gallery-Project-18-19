function addTask() {
    // Mendapatkan elemen input, daftar tugas, dan dropdown kategori dari DOM
    var taskInput = document.getElementById("taskInput");
    var taskList = document.getElementById("taskList");
    var categoryDropdown = document.getElementById("category");

    // Memeriksa apakah input tugas tidak kosong
    if (taskInput.value.trim() !== "") {
        // Membuat elemen <li> baru untuk tugas
        var newTask = document.createElement("li");

        // Mengatur teks dalam elemen <li> sesuai dengan nilai input dan kategori yang dipilih
        newTask.textContent = `${categoryDropdown.value}: ${taskInput.value}`;

        // Menambahkan elemen <li> ke dalam elemen daftar tugas (ul)
        taskList.appendChild(newTask);

        // Mengosongkan nilai input setelah tugas ditambahkan
        taskInput.value = "";

        // Menambahkan event listener untuk elemen <li> yang baru dibuat
        newTask.addEventListener("click", function () {
            // Menghapus elemen <li> saat di-klik
            this.parentNode.removeChild(this);
        });
    }
}
