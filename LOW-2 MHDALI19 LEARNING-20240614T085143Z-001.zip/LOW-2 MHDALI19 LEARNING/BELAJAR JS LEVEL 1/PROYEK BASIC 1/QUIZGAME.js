// QUIZ GAME ALGORITHM

// 1. H1 = JUDUL PERMAINAN
// 2. H2 = DEKSRIPSIS SINGKAT PERMAINAN
// 3. BUTTON = TOMBOL UNUTK MEMULAI PERMAINAN
// 4. GABUKGAN ITU DALAM SATU CONTAINER YAGN DINAMAKAN CONTAINER1
let judul = document.getElementsByTagName("h1")[0];
let deksripsi = document.getElementsByTagName("h2")[0];
let tombol = document.getElementsByTagName("button")[0];
let all = [judul, deksripsi, tombol];

tombol.addEventListener("click", () => {
    all[0].textContent = '';
    all[1].textContent = '';
    all[2].textContent = '';

    soal1();
})


// SOAL 1 
function soal1() {
    let soal1 = "Apa itu bahasa pemrograman?"
    let a = "A. Untuk ngoding"
    let b = "B. Untuk bikin program"
    let c = "C. Bahasa itu loh alat eh mesin"
    let d = "D. Lo nanya gw ha? gw nih kerja di OPEN AI lohhh"

    // Membuat elemen h1
    let sc = document.createElement("h1");
    sc.innerHTML = soal1;
    sc.style.textAlign = "left"

    // Membuat elemen ul untuk menyimpan jawaban
    let jawabanList = document.createElement("ul");

    // Membuat elemen li untuk setiap jawaban
    let ac = document.createElement("li")
    ac.textContent = a;
    let bc = document.createElement("li")
    bc.textContent = b;
    let cc = document.createElement("li")
    cc.textContent = c;
    let dc = document.createElement("li")
    dc.textContent = d;

    // Menambahkan elemen-elemen jawaban ke dalam elemen ul
    jawabanList.appendChild(ac);
    jawabanList.appendChild(bc);
    jawabanList.appendChild(cc);
    jawabanList.appendChild(dc);

    // Menambahkan elemen h1 dan ul ke dalam body dokumen
    document.body.appendChild(sc);
    document.body.appendChild(jawabanList);


    let tomoblkirim = document.createElement("button")
    tomoblkirim.textContent = "jawab"
    tomoblkirim.style.margin = "0"
    tomoblkirim.style.fontSize = "20px"
    document.body.appendChild(tomoblkirim)

    let all2 = [jawabanList, sc, tomoblkirim];


    tomoblkirim.addEventListener("click", () => {
        let jawab2 = prompt("Masukkan jawaban anda disini (hanya bisa dijawab dengan (a,b,c atau d) huruf kecil ya")
        all2[0].textContent = ""
        all2[1].textContent = ""
        all2[2].textContent = ""

        let totalnilai = "";

        if (jawab2 === "b") {
            totalnilai = 20;
        } else {
            totalnilai = 0;
        }

        soal2();
    })


}







// SOAL 2 
function soal2() {
    let soal1 = "Jika dia punya satu kaki maka dia benar jika jawaban dia selain dari itu maka dia salah, ketika lu membaca ini apa yg terlintas dipikiran lo"
    let a = "A. konsep if else"
    let b = "B. Ha? satu kaki cacat kah"
    let c = "C. Pertnayaan gk jelas "
    let d = "D. Konsep perulangan yg benar dalam javascript"

    // Membuat elemen h1
    let sc = document.createElement("h1");
    sc.innerHTML = soal1;
    sc.style.textAlign = "left"

    // Membuat elemen ul untuk menyimpan jawaban
    let jawabanList = document.createElement("ul");

    // Membuat elemen li untuk setiap jawaban
    let ac = document.createElement("li")
    ac.textContent = a;
    let bc = document.createElement("li")
    bc.textContent = b;
    let cc = document.createElement("li")
    cc.textContent = c;
    let dc = document.createElement("li")
    dc.textContent = d;

    // Menambahkan elemen-elemen jawaban ke dalam elemen ul
    jawabanList.appendChild(ac);
    jawabanList.appendChild(bc);
    jawabanList.appendChild(cc);
    jawabanList.appendChild(dc);

    // Menambahkan elemen h1 dan ul ke dalam body dokumen
    document.body.appendChild(sc);
    document.body.appendChild(jawabanList);


    let tomoblkirim = document.createElement("button")
    tomoblkirim.textContent = "jawab"
    tomoblkirim.style.margin = "0"
    tomoblkirim.style.fontSize = "20px"
    document.body.appendChild(tomoblkirim)

    let all2 = [jawabanList, sc, tomoblkirim];


    tomoblkirim.addEventListener("click", () => {
        let jawab2 = prompt("Masukkan jawaban anda disini (hanya bisa dijawab dengan (a,b,c atau d) huruf kecil ya")
        all2[0].textContent = ""
        all2[1].textContent = ""
        all2[2].textContent = ""

        soal3();
    })
}

//SOAL 3 
function soal3() {
    let soal1 = "Jika sebuah logika dengan perulangan yang tidak pasti apa bahasa lainnya"
    let a = "A. Hmm, mungkin jadi aneh"
    let b = "B. Asychorunus"
    let c = "C. Object Oriented Programming"
    let d = "D. Infnity loop"

    // Membuat elemen h1
    let sc = document.createElement("h1");
    sc.innerHTML = soal1;
    sc.style.textAlign = "left"

    // Membuat elemen ul untuk menyimpan jawaban
    let jawabanList = document.createElement("ul");

    // Membuat elemen li untuk setiap jawaban
    let ac = document.createElement("li")
    ac.textContent = a;
    let bc = document.createElement("li")
    bc.textContent = b;
    let cc = document.createElement("li")
    cc.textContent = c;
    let dc = document.createElement("li")
    dc.textContent = d;

    // Menambahkan elemen-elemen jawaban ke dalam elemen ul
    jawabanList.appendChild(ac);
    jawabanList.appendChild(bc);
    jawabanList.appendChild(cc);
    jawabanList.appendChild(dc);

    // Menambahkan elemen h1 dan ul ke dalam body dokumen
    document.body.appendChild(sc);
    document.body.appendChild(jawabanList);


    let tomoblkirim = document.createElement("button")
    tomoblkirim.textContent = "jawab"
    tomoblkirim.style.margin = "0"
    tomoblkirim.style.fontSize = "20px"
    document.body.appendChild(tomoblkirim)

    let all2 = [jawabanList, sc, tomoblkirim];


    tomoblkirim.addEventListener("click", () => {
        let jawab2 = prompt("Masukkan jawaban anda disini (hanya bisa dijawab dengan (a,b,c atau d) huruf kecil ya")
        all2[0].textContent = ""
        all2[1].textContent = ""
        all2[2].textContent = ""

        soal4();
    })
}

//SOAL 4
function soal4() {
    let soal1 = "Python or JavaScript?"
    let a = "A. Js lah lu punya js lu punya kuasa"
    let b = "B. Python lah lebih mudah"
    let c = "C. Python lah sekarannya eranya Ai bro"
    let d = "D. Jadilah bijak dengan tidak membadingkan keduanya"

    // Membuat elemen h1
    let sc = document.createElement("h1");
    sc.innerHTML = soal1;
    sc.style.textAlign = "left"

    // Membuat elemen ul untuk menyimpan jawaban
    let jawabanList = document.createElement("ul");

    // Membuat elemen li untuk setiap jawaban
    let ac = document.createElement("li")
    ac.textContent = a;
    let bc = document.createElement("li")
    bc.textContent = b;
    let cc = document.createElement("li")
    cc.textContent = c;
    let dc = document.createElement("li")
    dc.textContent = d;

    // Menambahkan elemen-elemen jawaban ke dalam elemen ul
    jawabanList.appendChild(ac);
    jawabanList.appendChild(bc);
    jawabanList.appendChild(cc);
    jawabanList.appendChild(dc);

    // Menambahkan elemen h1 dan ul ke dalam body dokumen
    document.body.appendChild(sc);
    document.body.appendChild(jawabanList);


    let tomoblkirim = document.createElement("button")
    tomoblkirim.textContent = "jawab"
    tomoblkirim.style.margin = "0"
    tomoblkirim.style.fontSize = "20px"
    document.body.appendChild(tomoblkirim)

    let all2 = [jawabanList, sc, tomoblkirim];


    tomoblkirim.addEventListener("click", () => {
        let jawab2 = prompt("Masukkan jawaban anda disini (hanya bisa dijawab dengan (a,b,c atau d) huruf kecil ya")
        all2[0].textContent = ""
        all2[1].textContent = ""
        all2[2].textContent = ""

        soal5();
    })
}

//SOAL 5
function soal5() {
    let soal1 = "Apakah belajar programmer itu susah"
    let a = "A. Susah asli nggak bohong gw susah mending lu jadi ui aja lah"
    let b = "B. Alahh its easy bro"
    let c = "C. Hmm, maybe not maybe yes"
    let d = "D. Tidak ada jawaban yang benar semuanya kembali kemasing masing pribadi"

    // Membuat elemen h1
    let sc = document.createElement("h1");
    sc.innerHTML = soal1;
    sc.style.textAlign = "left"

    // Membuat elemen ul untuk menyimpan jawaban
    let jawabanList = document.createElement("ul");

    // Membuat elemen li untuk setiap jawaban
    let ac = document.createElement("li")
    ac.textContent = a;
    let bc = document.createElement("li")
    bc.textContent = b;
    let cc = document.createElement("li")
    cc.textContent = c;
    let dc = document.createElement("li")
    dc.textContent = d;

    // Menambahkan elemen-elemen jawaban ke dalam elemen ul
    jawabanList.appendChild(ac);
    jawabanList.appendChild(bc);
    jawabanList.appendChild(cc);
    jawabanList.appendChild(dc);

    // Menambahkan elemen h1 dan ul ke dalam body dokumen
    document.body.appendChild(sc);
    document.body.appendChild(jawabanList);


    let tomoblkirim = document.createElement("button")
    tomoblkirim.textContent = "jawab"
    tomoblkirim.style.margin = "0"
    tomoblkirim.style.fontSize = "20px"
    document.body.appendChild(tomoblkirim)

    let all2 = [jawabanList, sc, tomoblkirim];


    tomoblkirim.addEventListener("click", () => {
        let jawab2 = prompt("Masukkan jawaban anda disini (hanya bisa dijawab dengan (a,b,c atau d) huruf kecil ya")
        all2[0].textContent = ""
        all2[1].textContent = ""
        all2[2].textContent = ""

        hasil();
    })
}

function hasil() {

    document.writeln(`<p> Nilai anda ${totalnilai}</p>`)
}





// 5. BUAT 5 SOAL TENTANG PROGRAMMING
// 6. 1 SOAL MEMILIKI 4 PILIHAN JAWABAN A,B,C,D.
// 7. BUAT SOAL MENGGUNAKAN H1 DAN JAWABAN MENGGUNAKAN LI
// 8. TAMPIKAN PERTANYAAN SATU PERSATU SESUAI URUTAN
// 9. SETLAAH SAMPAI KE SOAL 10 BARU HITUNG NILAINYA
// 10. 1 SOAL BERNILAI 20
// 11. TAMPILKAN JAWABAN BESERTA PESAN
// 12. JIKA NILAINYA DIBWAH 60 MAKA PESANNYA ADALAH "SANSS BROO TINGGAL BELAJAR LAGI LEBIH BANYAK"
// 13. JIKA NILAINYA DIATAS 60 MAKA PESANNYA ADALAH "KEREN BRO TINGKATKAN SKILLMU"
// 14. TAMBAHAKN TOMOBL MULAI ULANG

