function lPersegi(sisi) {
    return sisi * sisi;
}

function kPersegi(sisi) {
    return 4 * sisi;
}


function lPersegiPanjang(panjang, lebar) {
    return panjang * lebar;
}

function kPersegiPanjang(panjang, lebar) {
    return 2 * (panjang + lebar);
}


module.exports = {
    lPersegi,
    kPersegi,
    lPersegiPanjang,
    kPersegiPanjang,
};