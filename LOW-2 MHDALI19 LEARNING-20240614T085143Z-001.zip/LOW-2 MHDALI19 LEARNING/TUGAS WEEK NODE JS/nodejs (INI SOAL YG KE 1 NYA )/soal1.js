let hitung = require('./hitung');

const sisip = 19;
console.log(`Luas persegi adalah = ${hitung.lPersegi(sisip)}`)
console.log(`Keliling persegi adalah = ${hitung.kPersegi(sisip)}`)


const panjangPersegiPanjang = 20;
const lebarPersegiPanjang = 21;
console.log(`Luas persegi panjang adalah = ${hitung.lPersegiPanjang(panjangPersegiPanjang, lebarPersegiPanjang)}`);
console.log(`Keliling persegi panjang adalah = ${hitung.kPersegiPanjang(panjangPersegiPanjang, lebarPersegiPanjang)}`);
