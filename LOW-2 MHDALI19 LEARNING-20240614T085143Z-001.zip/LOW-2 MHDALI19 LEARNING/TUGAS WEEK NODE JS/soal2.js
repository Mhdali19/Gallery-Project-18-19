const axios = require('axios');
const fs = require('fs');

const dataUrl = 'https://gist.github.com/RezaNurRochmat13/291dcd64a10ff8c19f6b8b74107c85e2#file-homework-log';
const logFileName = 'log.txt';

async function fetchDataAndWriteLog() {
    try {
        // Ambil data dari URL
        const response = await axios.get(dataUrl);
        const dataText = response.data;

        console.log('Data dari URL:', dataText);

        // Pisahkan data menjadi baris-baris
        const lines = dataText.split('\n').map(line => line.trim()).filter(Boolean);

        // Tulis data ke dalam file log
        lines.forEach((line, index) => {
            fs.appendFileSync(logFileName, `Data ${index + 1}: ${line}\n`, 'utf8');
        });

        console.log(`Data berhasil ditulis ke dalam ${logFileName}`);
    } catch (error) {
        console.error('Error:', error.message);
    }
}

// Panggil fungsi utama
fetchDataAndWriteLog();
