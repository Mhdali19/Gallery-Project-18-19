document.querySelector("form").addEventListener("submit", function(event) {
    const name = document.querySelector("#name").value;
    const email = document.querySelector("#email").value;
    const message = document.querySelector("#message").value;
  
    if (!name) {
      alert("Please enter your name");
      event.preventDefault();
    } else if (!email) {
      alert("Please enter your email");
      event.preventDefault();
    } else if (!message) {
      alert("Please enter a message");
      event.preventDefault();
    }
  });
  