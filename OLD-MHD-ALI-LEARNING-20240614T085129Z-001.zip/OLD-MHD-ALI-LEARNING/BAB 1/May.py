#Variabel
#Meanru / assigment nilai
a = 10
b = 5 
ali = 19 

#pemannggilanpertama
print("Nilia a =", a)
print("Nilia b =", b)
print("Nilia ali =", ali)

#penamaan
nilai_c = 10 #underscre boleh
#nggak boleh  naro angka didepan
juta10 = 10000000 #boleh

#pemanggilankedua
print("Nilai a =", a)
a = 7
print("Nilai a =", a)

#assigment indirect
b = a
print("Nilai b =", b)

