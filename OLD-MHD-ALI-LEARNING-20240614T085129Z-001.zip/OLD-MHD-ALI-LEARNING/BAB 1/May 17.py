#If dan else

#1.If
#2. Kodisinya
#3. aksinya

nama = input("Siapa nama anda? ")

#if kondisi: aksi 
#program selanjutnya
#program selanjutnya

#1. program if in line
#if nama=="ucup" : print("Kamu Ganteng Abiezz!!!!!")
#print("Terima kasih {nama}")

#2. program if indection

#if nama=="ucup":  
 #   print("kamu ganteng abiezz!!!")
  #  print("kamu juga keren bosss")
#print(f"Terima kasih {nama}")

#3. Else statetment 


if nama=="otong":
    print("hai otoooong, si keren!!!")
else:
    print("Ah kamu bukan otong, kakmu gak keren! :(")

print("akhir dari program")