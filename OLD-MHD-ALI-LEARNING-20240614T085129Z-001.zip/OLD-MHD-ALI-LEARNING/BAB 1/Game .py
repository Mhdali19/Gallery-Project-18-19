import pygame

pygame.init()

height = 600
width = 600

screen = pygame.display.set_mode([height,width])

#mengubah warna screen

screen.fill((455,0,0))

running = True
while running:
    #loop
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.update()

pygame.quit()