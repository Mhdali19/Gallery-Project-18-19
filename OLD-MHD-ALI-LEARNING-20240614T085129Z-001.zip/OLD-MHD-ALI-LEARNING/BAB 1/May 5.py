#operasi aritmatika 

a = 10
b = 3

#operasi tambah +
hasil = a + b
print(a,'+',b,'=',hasil)

#operasi kurang -
hasil = a - b
print(a,'-',b,'=',hasil)

#operasi kali *
hasil = a * b
print(a,'*',b,'=',hasil)

#operasi bagi /
hasil = a / b
print(a,'/',b,'=',hasil)

#operasi flow division //
hasil = a // b
print(a,'//',b,'=',hasil)

#operasi eksponen (pangkat) **
hasil = a ** b
print(a,'**',b,'=',hasil)

#operasi modulus %
hasil = a % b
print(a,'%',b,'=',hasil)
 

# prioritas operasi 

x = 3 
y = 4
z = 20

hasil = x ** y % x + z - x * z
print(x,'**',y,'%',x,'+',z,'-',x,'*',z,'=',hasil) # kurung duluan 

