#oprator dalam bentuk methods

## merubah case dari string

#merubah semua ke upper case

salam = "bro!"
print("normal = " + salam)
salam =salam.upper()
print("upper = " + salam)

 #merubah ke lower case
alay = "aKu KeCe AbiezzzzzzzZZZ"
print("normal = " + alay)
alay = alay.lower()
print("lower = " + alay)

## pengecekan dengan isx method

#contoh pengecekan lower case
salam = "sist"
apakah_lower = salam.islower() 
print(salam + " is lower = " + str(apakah_lower))
apakah_upper = salam.isupper() 
print(salam + " is upper = " + str(apakah_upper))

#isalpha untuk mengecek huruf
#isalnum hurf dan angka
#isdecimal angka saja
#isspace spasi,tab,new line
#istittle semua dimulai dengan huruf besar

## ngecek komponen starswith() endswith()  keren
cek_start = "Oppa aja hasem".startswith("Oppa")
print("start = " + str(cek_start))

##penggabungan komponen join split
pisah = ['aku','sayang','kamu']
gabungan =','.join(pisah)
print(pisah)
print(gabungan)

gabungan ="akusayangehm"
print(gabungan.split('ehm'))

#alokasi karakter
print(5*"=" + "data" + "="*5)

kanan = "kanan".rjust(10)
print("'"+kanan+"'")
kiri = "kiri".ljust(10)
print("'"+kiri+"'")
tengah = "tengah".center(100,":")
print("'"+tengah+"'")

#kebalikannya strip
tengah = tengah.strip(":")
print("'"+tengah+"'")