# 1. cara membuat string

data = "ini adalah string"
print(data)
print(type(data))

'''
   1. dengan menggunakan single qoute '...'
   2. denga menggunakan double qoute "..."
'''

data = 'menggunakan single qoute'
print(data)

data = "menggunakan double qoute"
print(data)

print('"Halo, apa kabar?"')
print("'Halo, apa kabar?'")
print("ini adalah hari juma't")

# 2. menggunakan tanda \

# membuat tnada ' menjadi string
print('mari shalat jum\'at')
print('g\day, isn\'t it?')

# backslash
print("C:\\user\\ucup")

# tab
print("ucup\t\totong, jauhan")

#backspace
print("ucup \botong jadi deketan")

#new line
print("baris pertama.\nbaris kedua.") #LF = line feed
print("baris pertama.\rbaris kedua.") #CR = carriage return
print("baris pertama.\r\nbaris kedua") #CRLF = line feed carriage return = windows

# 3. String literal atau raw

#hati hati
print('C:\\new folder') 


#menggunakan raw
print(r'c:\new folder')

#multiline literal string
print("""
Nama : ucup
Kelas : 3 sd
""")

#multiline literal string raw

print(r"""
Nama : ucup
Kelas : 3 sd
website : www.ucup.com/new.id
""")