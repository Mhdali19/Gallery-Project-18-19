#While loop (perulangan)

#while kondisi :
#    aksi ini
  #  aksi itu 

angka = 0
print(f"angka sekarang -> {angka}") 

while angka < 5:
    angka += 1
    print(f"angka sekarang -> {angka}") 
    print("indah cantik!")

print("cukuup")