# episode 19
#multiline and with

#multiline

data_nama = "Ucup Surucup "
data_umur = 17
data_tinggi = 150.1
data_nomor_sepatu = 44

#string
data_string = f"nama = {data_nama}, umur = {data_umur}, tinggi = {data_tinggi}, sepatu = {data_nomor_sepatu}"
print(5*"="+"Data String"+5*"=")
print(data_string)

#String multiline (dengan menggunakan enter , newline \n)
data_string = f"nama = {data_nama} \n umur = {data_umur} \n tinggi = {data_tinggi} \n sepatu = {data_nomor_sepatu}"
print("\n"+5*"="+"Data String"+5*"=")
print(data_string)

#Stirign multiline (kutip triplets)

data_string = f"""
nama = {data_nama}
tinggi = {data_tinggi}
umur = {data_umur}
sepatu {data_nomor_sepatu}
"""
print("\n"+5*"="+"Data String"+5*"=")
print(data_string)


#mengatur lebar 
data_nama = "Ucup"
data_string = f"""
nama   = {data_nama:>10}
tinggi = {data_tinggi:>10}
umur   = {data_umur:>10}
sepatu = {data_nomor_sepatu:>10}
"""
print("\n"+5*"="+"Data String"+5*"=")
print(data_string)
