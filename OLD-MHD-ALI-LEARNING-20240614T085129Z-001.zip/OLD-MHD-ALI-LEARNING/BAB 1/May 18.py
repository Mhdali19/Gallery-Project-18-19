# ELIF = else if statement

nama = input("Nama anda siapa? ")

if nama =="Ali MJ":
    print("Wah leader MJ ',' selamat datang bosss!!")
elif nama == "Wegi MJ":
    print("Wah leader Ali MJ sudah masuk")
elif nama == "budi":
    print("siapa kamu keluar dari sini :)")
else:
    print("keluar atau kau kububuh")

print("ini adalah akhir dari program")

