#Loop atau perulangan 

#for kondisi

angka2_list = [0,1,2,3,4,5] #ini adalah list 
print(angka2_list)

for i in angka2_list:
    print(f"i sekarang -> {i}")

print("END \n")

#ini dengan range
angka2_range = range(6)

for i in angka2_range:
    print(f"i sekarang -> {i}")

print("END \n")


angka2_range = range(1,5)

for i in angka2_range:
    print(f"i sekarang -> {i}")

print("END")

#MENGGUNAKAN STRING

data_str = "ALI MJ 19"

for huruf in data_str:
    print(huruf)

print("END")